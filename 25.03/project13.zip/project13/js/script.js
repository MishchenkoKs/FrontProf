
/* 
function delayApi(delayedData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(delayedData);
        }, 3000)

    })
        .then((response) => {
            console.log(response);
        })
}

delayApi("hallo");

delayApi("delay 1 time")
    .then((response) => {
        console.log(response);
    })
    .then(() => {
        console.log('delayed 2 time');
    })
 */

/* const  fetchApi = async() => {

} */

async function fetchApi() {
    const url = "https://api.thecatapi.com/v1/images/search?size=med&mime_types=jpg&format=json&has_breeds=true&order=RANDOM&page=0&limit=1";
 
    try {
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error;
        }

        const data = await response.json();
        console.log(data["0"]);
        const dataUrl = data["0"].url;
        const dataId = data["0"].id;
        console.log(dataUrl);
        console.log(dataId);

        const randomCatSection = document.querySelector('.randomCat');
        const randomCatImgBlock = randomCatSection.querySelector('.randomCat__image');
        const randomCatInfoBlock = randomCatSection.querySelector('.randomCat__info');

        const randomCatImage = document.createElement('img');
        randomCatImage.setAttribute("src", dataUrl);
        randomCatImage.setAttribute("alt", "cat");
        randomCatImage.classList.add("randomCat__img");
        randomCatImgBlock.append(randomCatImage);

       const  randomCatIdBlock = document.createElement('p');
       randomCatIdBlock.textContent = `Id котика: ${dataId}`;
       randomCatInfoBlock.append(randomCatIdBlock);

       const  randomCatNameBlock = document.createElement('p');
       randomCatNameBlock.textContent = `Имя котика: Вася`;
       randomCatInfoBlock.append(randomCatNameBlock);

       const nameArr = ["Vasa", "Myrka", "Jake", "Katty", "Tom", "Jerry"];
       //const randomIndex = Math.random() * 


    } catch (e) {
        console.error('Request was not sent successfully', e);
    }

}


fetchApi();






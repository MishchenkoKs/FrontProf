// const stanleyArray = [
//   {
//     title: "Stanley Cooper 1",
//     description: "this is one of my favorite characters",
//     id: Date.now(),
//   },
//   {
//     title: "Stanley Cooper 2",
//     description: "this is one of my favorite characters",
//     id: Date.now(),
//   },
//   {
//     title: "Stanley Cooper 3",
//     description: "this is one of my favorite characters",
//     id: Date.now(),
//   },
//   {
//     title: "Stanley Cooper 4",
//     description: "this is one of my favorite characters",
//     id: Date.now(),
//   },
//   {
//     title: "Stanley Cooper 5",
//     description: "this is one of my favorite characters",
//     id: Date.now(),
//   },
//   {
//     title: "Stanley Cooper 6",
//     description: "this is one of my favorite characters",
//     id: Date.now(),
//   }
// ];

// const container = document.querySelector('.container')


// stanleyArray.forEach((item) => {
//     const newItem = document.createElement('div')
//     const newTitle = document.createElement('h3')
//     const itemImage = document.createElement('img')
//     const newDescription = document.createElement('p')
//     const additionalInfo = document.createElement('strong')
//     itemImage.setAttribute('src', './stanley.jpg')
//     newTitle.textContent = item.title
//     newItem.classList.add('item')
//     newDescription.textContent = item.description
//     additionalInfo.textContent = item.id
//     newItem.append(itemImage, newTitle, newDescription, additionalInfo)
//     container.append(newItem)
// })


async function userApi(userId){
  const url = `https://jsonplaceholder.typicode.com/users/${userId}`
  try{
      const response = await fetch(url);
      if(!response.ok){
      
          throw new Error('Ошибка при получении данных')
         
      }
      const data = await response.json();
      //1 шаг - функция возвращает данные
      // return data
      randomFN(data)
  }catch(error){
    console.error('Ошибка', error)
  }

}

//2 шаг - присваем результат функции в переменную ( function expression )
// const result = userApi(1)

//3 шаг - создаем новую АССИНХРОННУЮ функцию для вывода на страницу данных из нашей функции userApi
function randomFN(params) {

  //4 шаг - передаем результат функции в новую переменную params -> result -> userApi -> Данные из запроса
  const newElem = document.createElement('div')
  document.body.append(newElem)
  newElem.textContent = params.name + ' hello from inner function'
}
userApi(3)
// randomFN(result)
